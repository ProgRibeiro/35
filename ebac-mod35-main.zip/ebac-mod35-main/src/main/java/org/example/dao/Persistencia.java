package org.example.dao;
public interface Persistencia {

    //public Long getCodigo();

    public Long getId();

    public void setId(Long id);
}