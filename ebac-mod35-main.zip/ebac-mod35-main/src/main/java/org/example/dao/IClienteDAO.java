package org.example.dao;


import org.example.model.Cliente;

public interface IClienteDAO extends IGenericJapDAO<Cliente, Long>{

}
