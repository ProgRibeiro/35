package org.example.dao;


import org.example.model.Produto;

public interface IProdutoDAO extends IGenericJapDAO<Produto, Long>{

}