package org.example;

public enum PersistenceUnitName {

    CURSO;
}
